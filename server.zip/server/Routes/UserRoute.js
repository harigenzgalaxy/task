const express = require('express');
const router = express.Router();

const {
  getSomedata,
  getdatabyid
} = require('../controllers/studioController');

router.get('/', getSomedata);
router.get('/:id', getdatabyid);

module.exports = router;